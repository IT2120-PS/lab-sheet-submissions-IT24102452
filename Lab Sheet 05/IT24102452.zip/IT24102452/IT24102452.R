setwd("C:\\Users\\IT24102452\\Desktop\\IT24102452")
#1      
data<-read.table("Exercise - Lab 05.txt",header = TRUE,sep = ",")
fix(data)
attach(data)


names(data)<-c("X1")
attach(data)
hist(X1,main="Histogram for Delivery Times")
histrogram<-hist(X1,main="Histogram for Delivery Time",breaks = seq(20,70,length = 8),right = FALSE)

breaks<-round(histrogram$breaks)
freq<-histrogram$counts
mids<-histrogram$mids
classes<-c()
for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")")
}
cbind(Classes=classes,frequency=freq)

plot(mids,freq,type='l',main="Frequency polygon for Deliver Time",xlab="Deliver Times",ylab="Frequency",ylim=c(0,max(freq)))